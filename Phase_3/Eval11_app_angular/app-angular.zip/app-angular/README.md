# Annuaire des établissements scolaires (Angular)

## Lancer
```bash
npm install
ng serve
```
Puis ouvrir http://localhost:4200
