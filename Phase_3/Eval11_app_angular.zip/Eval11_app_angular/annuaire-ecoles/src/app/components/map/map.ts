import * as L from 'leaflet';

import {
  Component,
  AfterViewInit,
  Inject,
  PLATFORM_ID,
  Input,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-map',
  standalone: true,
  templateUrl: './map.html',
  styleUrl: './map.scss',
})
export class MapComponent implements AfterViewInit, OnChanges {

  @Input() schools: any[] = [];

  private map: any;
  private markersLayer: any;

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  async ngAfterViewInit(): Promise<void> {
    if (!isPlatformBrowser(this.platformId)) {
      return;
    }

    const L = await import('leaflet');

    // reset container Leaflet (important)
    const container = L.DomUtil.get('map');
    if (container) {
      // @ts-ignore
      container._leaflet_id = null;
    }

    this.map = L.map('map').setView([45.75, 4.85], 12);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(this.map);

    this.markersLayer = L.layerGroup().addTo(this.map);

    // 🔥 IMPORTANT : dessiner les markers si les données sont déjà là
    this.renderMarkers();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.renderMarkers();
  }

  private async renderMarkers(): Promise<void> {
    if (
      !isPlatformBrowser(this.platformId) ||
      !this.map ||
      !this.markersLayer ||
      !this.schools?.length
    ) {
      return;
    }

    const L = await import('leaflet');

    this.markersLayer.clearLayers();

    this.schools.forEach(school => {
      const fields = school.fields;

      if (fields?.latitude && fields?.longitude) {
        L.marker([fields.latitude, fields.longitude])
          .addTo(this.markersLayer);
      }
    });
  }
}
